from sound.echo import echo_test

def render_test():
    print("render")
    echo_test()
from sound import echo

echo.echo_test()
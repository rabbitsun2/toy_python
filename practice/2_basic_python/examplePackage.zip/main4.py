from graphic.render import render_test

render_test()
from sound.echo import echo_test

echo_test()